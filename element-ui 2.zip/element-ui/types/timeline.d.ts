import { ElementUIComponent } from './component'

/** Timeline Component */
export declare class ElTimeline extends ElementUIComponent {
  reverse: boolean
}
